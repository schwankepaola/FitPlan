import 'package:flutter/material.dart';
import '../services/notification_service.dart';
import '../services/auth_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final Color verde = const Color(0xFFC6FF00);

  List<Map<String, dynamic>> plano = [];

  bool carregando = true;

  String get nomeUsuario => AuthService.nome;
  int get idadeUsuario => AuthService.idade;
  double get pesoUsuario => AuthService.peso;
  int get diasSemanaUsuario => AuthService.diasSemana;

  @override
  void initState() {
    super.initState();
    carregarPlano();
  }

  Future<void> carregarPlano() async {
    final resultado = await AuthService().carregarPlano();

    setState(() {
      plano = resultado;
      carregando = false;
    });
  }

  int calcularProgresso() {
    if (plano.isEmpty) return 0;

    int concluidos = plano.where((treino) => treino['concluido'] == 1).length;

    return ((concluidos / plano.length) * 100).round();
  }

  String abreviarDia(String dia) {
    switch (dia.toLowerCase()) {
      case "segunda":
        return "SEG";

      case "terça":
      case "terca":
        return "TER";

      case "quarta":
        return "QUA";

      case "quinta":
        return "QUI";

      case "sexta":
        return "SEX";

      case "sábado":
      case "sabado":
        return "SAB";

      case "domingo":
        return "DOM";

      default:
        return dia.substring(0, 3).toUpperCase();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(14),

          child: Column(
            children: [
             Row(
  children: [
    Container(
      width: 55,
      height: 55,
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(30),
      ),
      child: const Icon(
        Icons.person,
        color: Colors.white,
        size: 30,
      ),
    ),

    const SizedBox(width: 15),

    Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Bem-vindo",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 14,
            ),
          ),

          Text(
            nomeUsuario,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 22,
            ),
          ),
        ],
      ),
    ),

    Container(
      width: 45,
      height: 45,
      decoration: BoxDecoration(
        color: const Color(0xff1E1E1E),
        borderRadius: BorderRadius.circular(15),
      ),
      child: IconButton(
        icon: const Icon(
          Icons.settings,
          color: Colors.white,
        ),
        onPressed: () {
          Navigator.pushNamed(context, "/configuracoes");
        },
      ),
    ),
  ],
),

              const SizedBox(height: 20),
                  Container(
  width: double.infinity,
  padding: const EdgeInsets.all(18),
  decoration: BoxDecoration(
    color: const Color(0xff111111),
    borderRadius: BorderRadius.circular(20),
    border: Border.all(color: Colors.white10),
  ),
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 5,
            ),
            decoration: BoxDecoration(
              color: verde,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              AuthService.objetivo.isEmpty
                  ? "Sem objetivo"
                  : AuthService.objetivo,
              style: const TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
          const Spacer(),
          Text(
            "${calcularProgresso()}%",
            style: TextStyle(
              color: verde,
              fontSize: 46,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),

      const SizedBox(height: 15),

      Row(
        children: [
          Text(
            "$idadeUsuario anos",
            style: const TextStyle(color: Colors.grey),
          ),
          const SizedBox(width: 20),
          Text(
            "${pesoUsuario.toStringAsFixed(0)} kg",
            style: const TextStyle(color: Colors.grey),
          ),
          const SizedBox(width: 20),
          Text(
            "${diasSemanaUsuario}x/sem",
            style: const TextStyle(color: Colors.grey),
          ),
        ],
      ),

      const SizedBox(height: 18),

      const Text(
        "Progresso semanal",
        style: TextStyle(
          color: Colors.grey,
          fontSize: 12,
        ),
      ),

      const SizedBox(height: 10),

      LinearProgressIndicator(
        value: plano.isEmpty
            ? 0
            : plano.where((t) => t['concluido'] == 1).length /
                plano.length,
        minHeight: 6,
        backgroundColor: Colors.white10,
        valueColor: AlwaysStoppedAnimation<Color>(verde),
      ),

      const SizedBox(height: 10),

     Align(
  alignment: Alignment.centerRight,
  child: Text(
    "${plano.where((t) => t['concluido'] == 1).length}/${plano.length} treinos",
    style: const TextStyle(color: Colors.grey),
  ),
),

],
),
),

const SizedBox(height: 20),

              if (carregando)
                const CircularProgressIndicator()
              else if (plano.isEmpty)
                const Text(
                  "Nenhum treino salvo",
                  style: TextStyle(color: Colors.grey),
                )
              else
             ...plano.map(
  (treino) => Container(
    margin: const EdgeInsets.only(bottom: 16),
    decoration: BoxDecoration(
      color: const Color(0xff171717),
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: Colors.white10),
    ),
    child: ExpansionTile(
      tilePadding: const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 8,
      ),
      childrenPadding: const EdgeInsets.fromLTRB(
        18,
        0,
        18,
        18,
      ),
      iconColor: Colors.white,
      collapsedIconColor: Colors.white,
      leading: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Center(
          child: Text(
            abreviarDia(treino['dia']),
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
      title: Text(
        treino['treino'],
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 18,
        ),
      ),
      subtitle: Text(
        treino['dia'],
        style: const TextStyle(color: Colors.grey),
      ),
      children: [
        const Divider(color: Colors.white10),

        const Align(
          alignment: Alignment.centerLeft,
          child: Text(
            "Exercícios",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),

        const SizedBox(height: 10),

        const Align(
          alignment: Alignment.centerLeft,
          child: Text(
            "Os exercícios aparecerão aqui.",
            style: TextStyle(color: Colors.grey),
          ),
        ),

        const SizedBox(height: 18),

        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: treino['concluido'] == 1
                  ? Colors.green
                  : verde,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 15),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            onPressed: () async {
              await AuthService().concluirTreino(treino['id']);
              await carregarPlano();

              if (!mounted) return;

              NotificationService.showTestNotification();

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Treino concluído com sucesso!"),
                ),
              );
            },
            child: Text(
              treino['concluido'] == 1
                  ? "TREINO CONCLUÍDO ✓"
                  : "MARCAR COMO CONCLUÍDO",
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ],
    ),
  ),
),

            ],
          ),
        ),
      ),
    );
  }
}